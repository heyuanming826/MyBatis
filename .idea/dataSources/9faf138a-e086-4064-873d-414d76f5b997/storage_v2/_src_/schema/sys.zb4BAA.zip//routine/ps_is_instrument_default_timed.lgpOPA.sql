CREATE FUNCTION ps_is_instrument_default_timed(in_instrument VARCHAR(128))
  RETURNS ENUM ('YES', 'NO')
  COMMENT '
 Description
 
 Returns whether an instrument is timed by default in this version of MySQL.
 
 Parameters
 
 in_instrument VARCHAR(128): 
 The instrument to check.
 
 Returns
 
 ENUM(''YES'', ''NO'')
 
 Example
 
 mysql> SELECT sys.ps_is_instrument_default_timed(''statement/sql/select'');
 +------------------------------------------------------------+
 | sys.ps_is_instrument_default_timed(''statement/sql/select'') |
 +------------------------------------------------------------+
 | YES                                                        |
 +------------------------------------------------------------+
 1 row in set (0.00 sec)
 '
  BEGIN DECLARE v_timed ENUM('YES', 'NO');  SET v_timed = IF(in_instrument LIKE 'wait/io/file/%' OR in_instrument LIKE 'wait/io/table/%' OR in_instrument LIKE 'statement/%' OR in_instrument IN ('wait/lock/table/sql/handler', 'idle')  OR in_instrument LIKE 'stage/innodb/%' OR in_instrument = 'stage/sql/copy to tmp table'  , 'YES', 'NO' );  RETURN v_timed; END;

